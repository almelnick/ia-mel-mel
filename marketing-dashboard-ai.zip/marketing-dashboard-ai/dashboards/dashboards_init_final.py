# dashboards/__init__.py
# Este archivo permite que Python reconozca 'dashboards' como un módulo