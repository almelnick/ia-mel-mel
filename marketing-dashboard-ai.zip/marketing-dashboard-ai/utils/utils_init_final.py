# utils/__init__.py
# Este archivo permite que Python reconozca 'utils' como un módulo