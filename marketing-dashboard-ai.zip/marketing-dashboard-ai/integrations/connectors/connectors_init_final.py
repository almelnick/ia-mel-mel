# integrations/connectors/__init__.py
# Este archivo permite que Python reconozca 'connectors' como un submódulo